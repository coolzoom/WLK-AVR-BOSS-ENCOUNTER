﻿local L

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "enUS", true, true)
if L then
end

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "deDE")
if L then
end

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "esES")
if L then
end

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "esMX")
if L then
end

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "frFR")
if L then
end

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "koKR")
if L then
end

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "ruRU")
if L then
end

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "zhCN")
if L then
end

L = LibStub("AceLocale-3.0"):NewLocale("AVRE Ulduar", "zhTW")
if L then
end
